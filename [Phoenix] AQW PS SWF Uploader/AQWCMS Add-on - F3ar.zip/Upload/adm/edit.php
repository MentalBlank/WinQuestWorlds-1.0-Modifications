<?php
include "../wqw/config.php";
session_start();
if(!isset($_SESSION['adm'])){
	header('location: ../login.php');
	exit();
} else {
	if(isset($_GET['id'])){
		if(is_numeric($_GET['id'])){
			$id = $_GET['id'];
			$sql = mysql_query("SELECT * FROM wqw_news WHERE id = '$id'");
			if ($data = mysql_fetch_assoc($sql)) {
				$title = $data['title'];
				$text = $data['text'];
				$poster = $data['poster'];
				$id = $data['id'];
				$msg = '<form action="edit.php" method="POST"><table border="0">
						<tr><td>Poster:</td> <td><input type="text" name="poster" value="'.$poster.'" /></td></tr>
						<tr><td>Title:</td> <td><input type="text" name="title" value="'.$title.'" /></td></tr></table>
						<textarea name="text" cols="65" rows="6">'.$text.'</textarea><br />
						<input type="submit" value="Edit post #'.$id.'" />
						<input type="hidden" name="submitted" value="true" />
						<input type="hidden" name="id" value="'.$id.'" /></form>';
			} else {
				$msg = "Error gathering the post's data.  Are you sure it's a real post?";
			}
		} else {
			$msg = "The ID is not a number.";
		}
	} elseif (isset($_POST['submitted'])){
		$poster = mysql_real_escape_string(stripslashes($_POST['poster']));
		$title = mysql_real_escape_string(stripslashes($_POST['title']));
		$text = mysql_real_escape_string(stripslashes($_POST['text']));
		$id = mysql_real_escape_string(stripslashes($_POST['id']));
		$sql = mysql_query("UPDATE wqw_news SET text = '$text', title = '$title', poster = '$poster' WHERE id = '$id'");
		if($sql){ $msg = "The post number ".$id." has been successfully updated!"; }
	} else {
		$msg = "The ID is not set.";
	}
}
?>
<html>
	<head>
		<meta name="Title" content="F3ar's WQW CMS" />
		<meta name="Author" content="F3ar/Quinn Heagy" />
		<title>F3ar's WQW CMS</title>
		<?php if ($msg == "The post number ".$id." has been successfully updated!") { echo '<meta http-equiv="REFRESH" content="3;url=index.php">'; } ?>
		<link type="text/css" rel="stylesheet" href="../css/main.css" />
	</head>
	<body>
		<div id="content">
			<?php include "../sidebar.php"; ?>
			<div id="main-content-area">
				<?php echo $msg; ?>
			</div>
			<?php include "sidebar-right.php"; ?>
		</div>
	</body>
</html>