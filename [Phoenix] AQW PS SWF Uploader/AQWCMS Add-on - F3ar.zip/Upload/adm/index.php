<?php
session_start();
if(!isset($_SESSION['adm'])){
	header('location: ../index.php');
} else {
	$msg = '<a href="write.php">Write some news</a><br />
			<a href="delete.php">Delete some news</a><br />
			<a href="edit.php?id=ID HERE">Edit some news</a>';
}
?>
<html>
	<head>
		<meta name="Title" content="F3ar's WQW CMS" />
		<meta name="Author" content="F3ar/Quinn Heagy" />
		<title>F3ar's WQW CMS</title>
		<link type="text/css" rel="stylesheet" href="../css/main.css" />
	</head>
	<body>
		<div id="content">
			<?php include "../sidebar.php"; ?>
			<div id="main-content-area">
				<?php echo $msg; ?>
			</div>
			<?php include "sidebar-right.php"; ?>
		</div>
	</body>
</html>