    <div id="left-sidebar">
        <?php
		include "../wqw/config.php";
		$query = "SELECT * FROM wqw_news ORDER BY id DESC LIMIT 4";
		$result = mysql_query($query);
		$num = mysql_numrows($result);
		mysql_close();
		$i = 0;
		while ($i < $num) {
			$id = mysql_result($result,$i,"id");
			$text = mysql_result($result,$i,"text");
			$title = mysql_result($result,$i,"title");
			$date = mysql_result($result,$i,"date");
			$poster = mysql_result($result,$i,"poster");
			echo "<h4>".$title."</h4><h6>Posted by ".$poster." on ".$date."<br /><a href=\"../news.php?id=".$id."\">Read about it!</a></h6><hr>";
			$i++;
		} 
		?>
		<script type="text/javascript"><!--
			google_ad_client = "pub-3265099106149937";
			/* 120x240, created 5/29/10 */
			google_ad_slot = "1335071973";
			google_ad_width = 120;
			google_ad_height = 240;
			//-->
		</script>
		<script type="text/javascript"
			src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
    </div>
