<?php
include "../wqw/config.php";
session_start();
if(!isset($_SESSION['adm'])){
	header('location: ../login.php');
	exit();
} else {
	if(isset($_GET['id'])){
		if(is_numeric($_GET['id'])){
			$id = $_GET['id'];
			$result = mysql_query("DELETE FROM wqw_news WHERE id = '$id'");
			if ($result) {
				$msg = "Your post has been deleted!";
			} else {
				$msg = "Your post has not been deleted.  Are you sure it's a correct ID?"; 
			}
		} else {
			$msg = "The string you have entered is not a number. Please go back and try again.";
		}
	} else {
		$msg = '<form action="delete.php" method="GET">
				Post ID: <input type="text" size="3" name="id" />
				<input type="submit" value="Delete" />
				</form>';
	}
}
?>
<html>
	<head>
		<meta name="Title" content="F3ar's WQW CMS" />
		<meta name="Author" content="F3ar/Quinn Heagy" />
		<title>F3ar's WQW CMS</title>
		<?php if ($msg == "Your post has been deleted!") { echo '<meta http-equiv="REFRESH" content="3;url=index.php">'; } ?>
		<link type="text/css" rel="stylesheet" href="../css/main.css" />
	</head>
	<body>
		<div id="content">
			<?php include "../sidebar.php"; ?>
			<div id="main-content-area">
				<?php echo $msg; ?>
			</div>
			<?php include "sidebar-right.php"; ?>
		</div>
	</body>
</html>