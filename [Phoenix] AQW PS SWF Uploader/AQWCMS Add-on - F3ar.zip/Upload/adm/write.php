<?php
include "../wqw/config.php";
session_start();
if(!isset($_SESSION['adm'])){
	header('location: ../login.php');
	exit();
} else {
	if(isset($_POST['submitted'])){
		$title = mysql_real_escape_string(stripslashes($_POST['title']));
		$text = mysql_real_escape_string(stripslashes($_POST['text']));
		$query = "SELECT * FROM wqw_news ORDER BY id DESC";
		$result = mysql_query($query);
		$i = 0;
		$id = mysql_result($result,$i,"id");
		$id++;
		$date = date("F j, Y, g:i a");
		$poster = $_SESSION['name'];
		$ip = $_SERVER['REMOTE_ADDR'];
		$sql = mysql_query("INSERT INTO wqw_news (id, ip, title, text, poster, date) VALUES ('$id', '$ip', '$title', '$text', '$poster', '$date')");
		if($sql){
			$msg = "Your post has been published!";
		} else {
			$msg = "There was an error publishing your post.  Please try again.";
		}
	} else {
		$msg = '<form action="write.php" method="POST">
				<input type="text" name="title" /><br />
				<textarea name="text" cols="65" rows="6"></textarea><br />
				<input type="submit" name="submit" value="Publish" />
				<input type="hidden" name="submitted" value="true" />
				</form>';
	}
	?>
<html>
	<head>
		<meta name="Title" content="F3ar's WQW CMS" />
		<meta name="Author" content="F3ar/Quinn Heagy" />
		<title>F3ar's WQW CMS</title>
		<link type="text/css" rel="stylesheet" href="../css/main.css" />
	</head>
	<body>
		<div id="content">
			<?php include "../sidebar.php"; ?>
			<div id="main-content-area">
				<?php echo $msg; ?>
			</div>
			<?php include "sidebar-right.php"; ?>
		</div>
	</body>
</html>

	
	<?php
}
?>