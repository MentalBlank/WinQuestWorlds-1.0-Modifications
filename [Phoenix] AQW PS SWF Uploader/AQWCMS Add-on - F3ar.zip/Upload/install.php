<?php
include "wqw/config.php";
if($_GET['mode'] == "install"){
	$sql = mysql_query("CREATE TABLE IF NOT EXISTS `wqw_news` (
  `id` int(11) NOT NULL,
  `ip` varchar(16) NOT NULL,
  `poster` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;") or die(mysql_error());
	$date = date("F j, Y, g:i a");
	$sql2 = mysql_query("INSERT INTO `wqw_news` (`id`, `ip`, `poster`, `title`, `text`, `date`) VALUES
(0, '127.0.0.1', 'F3ar', 'Congratulations', 'You have successfully set up your CMS.<br />From here, you can edit or delete this post.', '$date');") or die(mysql_error());
	if(($sql) && ($sql2)){
		$msg = "You're news system has been installed!";
	} else {
		$msg = "There was an error installing your news system.  If you see this warning, please contact F3ar on Cris' Forum";
	}
} else {
	$msg = "Please click <a href='install.php?mode=install'>here</a> to install your news system.";
}
echo $msg;
?>