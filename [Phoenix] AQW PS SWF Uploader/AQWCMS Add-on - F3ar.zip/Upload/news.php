<?php
session_start();
	if(isset($_SESSION['user'])){
		header('location: home.php');
	} else {
		include "wqw/config.php";
	}
?>
<html>
	<head>
		<meta name="Title" content="F3ar's WQW CMS" />
		<meta name="Author" content="F3ar/Quinn Heagy" />
		<title>F3ar's WQW CMS</title>
		<link type="text/css" rel="stylesheet" href="/css/main.css" />
	</head>
	<body>
		<div id="content">
			<?php include "sidebar.php"; ?>
			<div id="main-content-area">
			<?php
			if(isset($_GET['id'])) {
				$id = mysql_real_escape_string(stripslashes($_GET['id']));
				$result = mysql_query("SELECT * FROM wqw_news WHERE id = '$id'");
				$text = mysql_result($result,$i,"text");
				$title = mysql_result($result,$i,"title");
				$date = mysql_result($result,$i,"date");
				$poster = mysql_result($result,$i,"poster");
				if(isset($_SESSION['adm'])){
						$edit = " - <a href=\"../adm/edit.php?id=".$id."\">Edit this post</a>";
					}
				echo "<h2>".$title."</h2>
				<h5>Posted by ".$poster." on ".$date."</h5>
				<p>".$text."</p><a href=\"news.php?id=".$id."\">Read More</a>".$edit."
				<br /><hr>";
			} elseif (isset($_GET['num'])){
				$num = $_GET['num'];
				$query = "SELECT * FROM wqw_news ORDER BY id DESC LIMIT $num";
				$result = mysql_query($query);
				$num = mysql_numrows($result);
				mysql_close();
				$i = 0;
				while ($i < $num) {
					$id = mysql_result($result,$i,"id");
					$text = mysql_result($result,$i,"text");
					$title = mysql_result($result,$i,"title");
					$date = mysql_result($result,$i,"date");
					$poster = mysql_result($result,$i,"poster");
					if(isset($_SESSION['adm'])){
						$edit = " - <a href=\"../adm/edit.php?id=".$id."\">Edit this post</a>";
					}
					echo "<h2>".$title."</h2>
					<h5>Posted by ".$poster." on ".$date."</h5>
					<p>".$text."</p><a href=\"news.php?id=".$id."\">Read More</a>".$edit."
					<br /><hr>";
					$i++;
				} 
			} else {
				$query = "SELECT * FROM wqw_news ORDER BY id DESC LIMIT 10";
				$result = mysql_query($query);
				$num = mysql_numrows($result);
				mysql_close();
				$i = 0;
				while ($i < $num) {
					$id = mysql_result($result,$i,"id");
					$text = mysql_result($result,$i,"text");
					$title = mysql_result($result,$i,"title");
					$date = mysql_result($result,$i,"date");
					$poster = mysql_result($result,$i,"poster");
					if(isset($_SESSION['adm'])){
						$edit = "- <a href=\"../adm/edit.php?id=".$id."\">Edit this post</a>";
					}
					echo "<h2>".$title."</h2>
					<h5>Posted by ".$poster." on ".$date."</h5>
					<p>".$text."</p><a href=\"news.php?id=".$id."\">Read More</a>".$edit."
					<br /><hr>";
					$i++;
				} 
			}
			?>
			</div>
			<?php include "sidebar-right.php"; ?>
		</div>
	</body>
</html>
