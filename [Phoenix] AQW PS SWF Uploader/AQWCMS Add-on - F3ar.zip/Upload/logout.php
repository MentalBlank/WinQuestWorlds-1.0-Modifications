<?php
session_start();
if(isset($_SESSION['adm'])){
	unset($_SESSION['adm']);
}
unset($_SESSION['name']);
unset($_SESSION['user']);
$msg = "You are now logged out.";
?>
<html>
	<head>
		<meta name="Title" content="F3ar's WQW CMS" />
		<meta name="Author" content="F3ar/Quinn Heagy" />
		<title>F3ar's WQW CMS</title>
		<meta http-equiv="REFRESH" content="3;url=index.php">
		<link type="text/css" rel="stylesheet" href="css/main.css" />
	</head>
	<body>
		<div id="content">
			<?php include "sidebar.php"; ?>
			<div id="main-content-area">
				<?php echo $msg; ?>
			</div>
			<?php include "sidebar-right.php"; ?>
		</div>
	</body>
</html>