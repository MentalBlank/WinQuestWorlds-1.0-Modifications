<?php
include "wqw/config.php";
session_start();
if(!isset($_SESSION['name'])){
	if(isset($_POST['submitted'])){
		$user = mysql_real_escape_string(stripslashes($_POST['user']));
		$pass = md5($_POST['pass']);
		$query = mysql_query("SELECT username, password FROM wqw_users WHERE username = '$user'") or die(mysql_error());
		if ($data = mysql_fetch_assoc($query)) {
			if($data['username'] != $user){
				$msg = "Your username is  incorrect. Please try again.";
			} elseif ($data['password'] != $pass){
				$msg = "Your password is incorrect. Please try again.";
			} else {
				$query = mysql_query("SELECT * FROM `wqw_users` WHERE `username` = '".$user."' AND `password` = '".$pass."'") or die(mysql_error());
				if ($query) {
					$_SESSION['name'] = $user;
					if ($data = mysql_fetch_assoc($query)){
						if($data['access'] == "50"){
							$_SESSION['adm'] = "true";
						}
					}
					$msg = "Login successful.";
				} else {
					$msg = "There was an error when you tried to login. Please don't refresh the page. This may just be a fluke.";
				}
			}
		} else {
			$msg = "Your username or password is incorrect.  Please try again.";
		}
	} else {
		$msg = "<table border='0'><form action='' method='post'>
		<tr><td>Username:</td> <td><input type='text' name='user' /></td></tr>
		<tr><td>Password:</td> <td><input type='password' name='pass' /></td></tr>
		<tr><td><input type='submit' name='login' value='Login' /></td></tr>
		<input type='hidden' name='submitted' value='true' /></table>";
	}
} else {
	$msg = "You're already logged in.";
}
?>
<html>
	<head>
		<meta name="Title" content="F3ar's WQW CMS" />
		<meta name="Author" content="F3ar/Quinn Heagy" />
		<title>F3ar's WQW CMS</title>
		<?php if($msg == "Login successful."){ echo "<meta http-equiv=\"REFRESH\" content=\"3;url=index.php\">"; } ?>
		<link type="text/css" rel="stylesheet" href="css/main.css" />
	</head>
	<body>
		<div id="content">
			<?php include "sidebar.php"; ?>
			<div id="main-content-area">
				<?php echo $msg; ?>
			</div>
			<?php include "sidebar-right.php"; ?>
		</div>
	</body>
</html>