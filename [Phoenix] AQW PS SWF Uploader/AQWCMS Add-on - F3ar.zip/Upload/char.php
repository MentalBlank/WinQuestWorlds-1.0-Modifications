<?php
session_start();
include "wqw/config.php";
if(!isset($_SESSION['name'])){
	$msg = "Please login <a href=\"login.php\">here</a>.";
} else {
	$name = $_SESSION['name'];
	$sql = mysql_query("SELECT * FROM wqw_users WHERE username = '$name'");
	if ($data = mysql_fetch_assoc($sql)){
	$set_email = htmlspecialchars($data['email']);
	$set_password = $data['password'];
	}
	if(isset($_POST['submitted'])){
		if(isset($_POST['email'])){
			if($_POST['email'] == $_POST['email_confirm']){
				if($_POST['email'] != ""){
					$new_email = mysql_real_escape_string(stripslashes(htmlspecialchars($_POST['email'])));
					$query = mysql_query("UPDATE wqw_users SET email = '$new_email' WHERE username = '$name'");
				}
			} else {
				$msg = "The emails do not match. Please try again.";
			}
		} 
		if (isset($_POST['password'])){
			if($_POST['password'] == $_POST['pass_confirm']){
				if($_POST['password'] != ""){
					$new_pass = md5($_POST['password']);
					$query2 = mysql_query("UPDATE wqw_users SET password = '$new_pass' WHERE username = '$name'");
				}
			} else {
				$msg = "The passwords do not match. Please try again.";
			}
		}
	
		if((isset($query)) && (isset($query2))){
			$msg = "Your email and password have been successfully updated";
		} elseif (isset($query2)){
			$msg = "Your password has been successfully updated";
		} elseif (isset($query)){
			$msg = "Your email has been updated";
		} else {
			$msg = "wat";
		}
	} else {
	$msg = '<table border="0"><form action="" method="POST">
			<tr><td>New Email:</td> <td><input type="email" name="email" value="'.$set_email.'" /></td></tr>
			<tr><td>Confirm:</td> <td><input type="email" name="email_confirm" value="" /></td></tr>
			<tr><td></td><td></td></tr>
			<tr><td>New Password:</td> <td><input type="password" name="password" value="" /></td></tr>
			<tr><td>Confirm:</td> <td><input type="password" name="pass_confirm" value="" /></td></tr>
			<tr><td><input type="submit" value="Update" />
			<input type="hidden" name="submitted" /></table>';
	}
}
	
?>
<html>
	<head>
		<meta name="Title" content="F3ar's WQW CMS" />
		<meta name="Author" content="F3ar/Quinn Heagy" />
		<title>F3ar's WQW CMS</title>
		<link type="text/css" rel="stylesheet" href="css/main.css" />
	</head>
	<body>
		<div id="content">
			<?php include "sidebar.php"; ?>
			<div id="main-content-area">
				<?php echo $msg; ?>
			</div>
			<?php include "sidebar-right.php"; ?>
		</div>
	</body>
</html>